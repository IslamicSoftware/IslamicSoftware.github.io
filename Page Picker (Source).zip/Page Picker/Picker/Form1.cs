﻿//     بـسم الله الرحمن الرحيم  
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;

namespace Picker
{
    public partial class Form1 : Form
    {

        Dictionary<string, string> dictionary_months = new Dictionary<string, string>() {
            {"Muharram","1"},
            {"Safar","2"},
            {"Rabi I","3"},
            {"Rabi II","4"},
            {"Jumada I","5"},
            {"Jumada II","6"},
            {"Rajab","7"},
            {"Shaaban","8"},
            {"Ramadan","9"},
            {"Shawwal","10"},
            {"Dhu al-Qidah","11"},
            {"Dhu al-Hijjah","12"}
        };

        WebClient client = new WebClient();
        string url = "https://timesprayer.com/en/prayer-times-in-makkah.html";

        string patterntime = "timenowinthecity\"\\s*>\\d+:\\d+:\\d+";

        string patterndate = "(?<=(Friday|Saturday|Sunday|Monday|Tuesday|Wednesday|Thursday)\\s*)\\d+\\s*.+\\s*14\\d\\d(?=\\s*Hijri)";

        string patterntimeremainingforazan = "id=\"countdown\" class=\"txt-center\">\\d+:\\d+:\\d+";


        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string htmlCode = client.DownloadString(url);
                string timestr = Regex.Match(htmlCode, patterntime).Value;
                string datestr = Regex.Match(htmlCode, patterndate).Value;
                string timeremainingforazan = Regex.Match(htmlCode, patterntimeremainingforazan).Value;
                string month = Regex.Replace(datestr, "[0-9]", "").Trim();

                
                if(dictionary_months.ContainsKey(month))
                {
                    string monthnumber = dictionary_months[month];

                    datestr = datestr.Replace(month, monthnumber);

                    label1.Text = (((((Convert.ToInt64(Regex.Replace(datestr, "[^0-9]", "") + Regex.Replace(timestr, "[^0-9]", ""))) % 606) * Convert.ToInt64(Regex.Replace(timeremainingforazan, "[^0-9]", ""))) % 606).ToString());

                    Clipboard.SetText(label1.Text);
                }
                else
                {
                    if(MessageBox.Show("Month not found in the list. Open the webpage in the web-browser?","",MessageBoxButtons.YesNo)==DialogResult.Yes)
                    {
                        System.Diagnostics.Process.Start(url);
                    }
                }

                
                
            }
            catch
            {
                label1.Text = "Try Later!";
                return;
            }

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
